
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author dsm-2
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Cliente cli = new Cliente();
        int op;
        double a, b;
        
        do{
            op = Integer.parseInt(JOptionPane.showInputDialog("Digite uma opção: \n 1 - Cadastrar Cliente" + "\n 2 - Listar Cliente" + "\n 3 - Calcular Limite de Crédito" + "\n 0 - Sair"));
            
            switch(op){
                case 1:
                    cli.cadastrarCliente();
                break;
                case 2:
                    cli.listarCliente();
                break; 
                case 3:
                    cli.calcularLimiteCredito();
                break;
                case 0:
                    JOptionPane.showMessageDialog(null, "Você decidiu sair.");
                break;
                default:
                    JOptionPane.showMessageDialog(null, "Opção inválida!");
                break;
            }
            
        }while(op != 0);
        
    }
    
}
